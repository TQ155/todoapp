
from flask import Flask, render_template, request, redirect, url_for, jsonify , abort
from flask_sqlalchemy import SQLAlchemy ; 
from flask_migrate import Migrate ; 
import sys
# Run :  FLASK_APP=Todos.py FLASK_DEBUG=true flask run
# export FLASK_APP=Todo.py
# flask db init 
# flask db migrate
# flask db upgrade 
# flask db downgrade
# Model 

app = Flask(__name__ , template_folder = 'template')
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres@localhost:5432/todoapp'
db = SQLAlchemy(app)
migrate = Migrate(app, db)

class Todo(db.Model):
    __tablename__ = "todo"
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(128))
    #completed = db.Column(db.Boolean , nullable = False , default = False)
    
    def __repr__(self):
      return 'Todo(id=%s, description=%s))' % (self.id, self.description)

# Controller 
@app.route('/')
def index():
  print(Todo.query.all())
  return render_template('index.html', data=Todo.query.all())

@app.route('/todos/create', methods=['POST'])
def create_todo(): # handler function 
  error = False
  body = {}
  #description = request.form.get('description', '') # matches the form input description # before ajax
  description = request.get_json()['description'] # matches the form input description 
  try:
  
    todo = Todo(description=description) #create new todo object 
    db.session.add(todo) # save it 
    db.session.commit() # commit it `
    body["description"] = todo.description
  # return redirect(url_for('index')) # before ajax 
      
  except: 
    db.session.rollback()
    print("error hapened")
    error = True #
    print(sys.exc_info)
    
  finally:
    db.session.close()
  
  if not error:
    return jsonify(body)
  


#always include this at the bottom of your code (port 3000 is only necessary in workspaces)

if __name__ == '__main__':
   app.run(host="0.0.0.0", port=3000)
   